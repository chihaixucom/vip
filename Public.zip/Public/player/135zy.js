document.write('<iframe width="100%" height="100%" class="embed-responsive-item" src="'+cms_player.url+'" frameborder="0" border="0" marginwidth="0" marginheight="0" scrolling="no"></iframe>');
