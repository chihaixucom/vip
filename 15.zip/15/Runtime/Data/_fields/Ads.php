<?php
return array (
  0 => 'ads_id',
  1 => 'ads_name',
  2 => 'ads_content',
  '_autoinc' => true,
  '_pk' => 'ads_id',
  '_type' => 
  array (
    'ads_id' => 'smallint(4) unsigned',
    'ads_name' => 'varchar(50)',
    'ads_content' => 'text',
  ),
);
?>