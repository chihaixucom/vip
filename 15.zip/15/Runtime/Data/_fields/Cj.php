<?php
return array (
  0 => 'cj_id',
  1 => 'cj_name',
  2 => 'cj_url',
  3 => 'cj_type',
  4 => 'cj_appid',
  5 => 'cj_appkey',
  '_autoinc' => true,
  '_pk' => 'cj_id',
  '_type' => 
  array (
    'cj_id' => 'smallint(6)',
    'cj_name' => 'varchar(255)',
    'cj_url' => 'varchar(255)',
    'cj_type' => 'tinyint(2)',
    'cj_appid' => 'varchar(50)',
    'cj_appkey' => 'varchar(50)',
  ),
);
?>