<?php
return array (
  0 => 'card_id',
  1 => 'card_number',
  2 => 'card_face',
  3 => 'card_uid',
  4 => 'card_status',
  5 => 'card_addtime',
  6 => 'card_usetime',
  '_autoinc' => true,
  '_pk' => 'card_id',
  '_type' => 
  array (
    'card_id' => 'int(11)',
    'card_number' => 'varchar(64)',
    'card_face' => 'mediumint(8)',
    'card_uid' => 'int(11)',
    'card_status' => 'tinyint(1)',
    'card_addtime' => 'int(11)',
    'card_usetime' => 'int(11)',
  ),
);
?>