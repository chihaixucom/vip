<?php 
header("Location: /index.php?s=/ajax-404.html"); 
exit;
?>  