<?php
return array (
  0 => 'tag_id',
  1 => 'tag_cid',
  2 => 'tag_name',
  3 => 'tag_list',
  4 => 'tag_ename',
  '_autoinc' => false,
  '_type' => 
  array (
    'tag_id' => 'mediumint(8)',
    'tag_cid' => 'tinyint(2)',
    'tag_name' => 'varchar(50)',
    'tag_list' => 'varchar(32)',
    'tag_ename' => 'varchar(255)',
  ),
);
?>