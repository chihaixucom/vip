<?php
return array (
  '_autoinc' => false,
  '_type' => NULL,
);
?>